# libproxy-extension
A chrome extension to automatically build UNC library proxy links.
